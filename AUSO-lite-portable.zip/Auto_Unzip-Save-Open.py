from __future__ import annotations

import argparse
import bz2
import configparser
import ctypes
from ctypes import wintypes
import gzip
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import tarfile
import time
import zipfile

APP_NAME = "Auto_Unzip-Save-Open-Lightweight"
TRAY_CLASS = APP_NAME + "-Tray"
STOP_EVENT = "Local\\" + APP_NAME + "-Stop"
TEMP_SUFFIXES = (".crdownload", ".part", ".partial", ".download", ".tmp")
ARCHIVE_SUFFIXES = (
    ".tar.gz", ".tar.bz2", ".tar.xz", ".tgz", ".tbz2", ".txz",
    ".zip", ".tar", ".gz", ".bz2", ".xz",
)
TRAY_FRAMES = [
    "loading1.ico", "loading2.ico", "loading3.ico", "loading4.ico",
    "loading5.ico", "loading6.ico", "loading7.ico", "loading8.ico",
    "loading9.ico", "loading10.ico", "loading11.ico", "loading12.ico",
    "loading13.ico", "loading14.ico",
]


def base_dir() -> Path:
    return Path(__file__).resolve().parent


def load_config() -> configparser.ConfigParser:
    config = configparser.ConfigParser(interpolation=None)
    config.read(base_dir() / "config.ini", encoding="utf-8")
    if "settings" not in config:
        config["settings"] = {}
    return config


def expand_path(text: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(text.strip().strip('"')))).resolve()


def paths(config: configparser.ConfigParser) -> tuple[Path, Path]:
    settings = config["settings"]
    text = settings.get("downloads_folder", "").strip()
    downloads = expand_path(text) if text else (Path.home() / "Downloads").resolve()
    text = settings.get("dump_folder", "").strip()
    dump = expand_path(text) if text else (downloads / "Dump").resolve()
    return downloads, dump


def excluded(path: Path, text: str) -> bool:
    name = path.name.lower()
    for item in text.split(","):
        value = item.strip().lower()
        if not value:
            continue
        if not value.startswith("."):
            value = "." + value
        if name.endswith(value):
            return True
    return False


def archive_suffix(path: Path) -> str | None:
    name = path.name.lower()
    for suffix in ARCHIVE_SUFFIXES:
        if name.endswith(suffix):
            return suffix
    return None


def safe_name(name: str) -> bool:
    p = PurePosixPath(name.replace("\\", "/"))
    return not p.is_absolute() and ".." not in p.parts and not any(":" in part for part in p.parts)


def progress_copy(src, dst, total: int, done: int, callback) -> int:
    while True:
        chunk = src.read(1024 * 1024)
        if not chunk:
            break
        dst.write(chunk)
        done += len(chunk)
        callback(done, total)
    return done


def extract_zip(source: Path, destination: Path, callback) -> None:
    with zipfile.ZipFile(source) as archive:
        items = archive.infolist()
        for item in items:
            if not safe_name(item.filename):
                raise ValueError("Unsafe ZIP path")
            if stat.S_ISLNK((item.external_attr >> 16) & 0xFFFF):
                raise ValueError("ZIP links are not supported")
        total = sum(item.file_size for item in items if not item.is_dir())
        done = 0
        callback(0, total)
        for item in items:
            target = destination / item.filename
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(item, "r") as src, target.open("wb") as dst:
                done = progress_copy(src, dst, total, done, callback)
        callback(total, total)


def extract_tar(source: Path, destination: Path, callback) -> None:
    with tarfile.open(source, "r:*") as archive:
        members = archive.getmembers()
        for item in members:
            if not safe_name(item.name):
                raise ValueError("Unsafe TAR path")
            if item.issym() or item.islnk() or item.isdev() or item.isfifo():
                raise ValueError("TAR links and devices are not supported")
        total = sum(item.size for item in members if item.isfile())
        done = 0
        callback(0, total)
        for item in members:
            target = destination / item.name
            if item.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            if not item.isfile():
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            src = archive.extractfile(item)
            if src is None:
                continue
            with src, target.open("wb") as dst:
                done = progress_copy(src, dst, total, done, callback)
        callback(total, total)


def extract_stream(source: Path, destination: Path, suffix: str, callback) -> None:
    target = destination / (source.name[:-len(suffix)] or source.stem or "output")
    total = source.stat().st_size
    raw = source.open("rb")
    try:
        if suffix == ".gz":
            stream = gzip.GzipFile(fileobj=raw, mode="rb")
        elif suffix == ".bz2":
            stream = bz2.BZ2File(raw, "rb")
        else:
            stream = lzma.LZMAFile(raw, "rb")
        with stream, target.open("wb") as dst:
            callback(0, total)
            while True:
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                dst.write(chunk)
                callback(min(raw.tell(), total), total)
            callback(total, total)
    finally:
        if not raw.closed:
            raw.close()


def output_folder(source: Path, suffix: str, dump: Path) -> Path:
    name = source.name[:-len(suffix)].rstrip(". ") or source.stem
    target = dump / name
    number = 2
    while target.exists():
        target = dump / f"{name} ({number})"
        number += 1
    return target


def unique_archive_target(folder: Path, source: Path) -> Path:
    suffix = "".join(source.suffixes)
    stem = source.name[:-len(suffix)] if suffix else source.name
    target = folder / source.name
    number = 2
    while target.exists():
        target = folder / f"{stem} ({number}){suffix}"
        number += 1
    return target


def recycle_file(path: Path) -> None:
    class FileOp(ctypes.Structure):
        _fields_ = [
            ("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT),
            ("pFrom", wintypes.LPCWSTR), ("pTo", wintypes.LPCWSTR),
            ("fFlags", wintypes.WORD), ("fAnyOperationsAborted", wintypes.BOOL),
            ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR),
        ]
    op = FileOp()
    op.wFunc = 3
    op.pFrom = str(path) + "\0\0"
    op.fFlags = 0x0040 | 0x0010 | 0x0004 | 0x0400
    result = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
    if result or op.fAnyOperationsAborted:
        raise OSError(result, "Could not move file to Recycle Bin")


def handle_original(source: Path, action: str) -> None:
    action = action.strip().strip('"')
    if not action or action.lower() in {"n", "no"}:
        return
    if action.lower() == "recycle":
        recycle_file(source)
        return
    folder = expand_path(action)
    folder.mkdir(parents=True, exist_ok=True)
    shutil.move(str(source), str(unique_archive_target(folder, source)))


def signature(path: Path) -> tuple[int, int]:
    item = path.stat()
    return item.st_size, item.st_mtime_ns


def stable(path: Path, seconds: float) -> bool:
    try:
        previous = signature(path)
    except OSError:
        return False
    unchanged_since = time.monotonic()
    deadline = time.monotonic() + 3600
    while time.monotonic() < deadline:
        time.sleep(0.25)
        try:
            current = signature(path)
        except OSError:
            return False
        if current != previous:
            previous = current
            unchanged_since = time.monotonic()
            continue
        if time.monotonic() - unchanged_since >= seconds:
            try:
                with path.open("rb"):
                    return True
            except OSError:
                unchanged_since = time.monotonic()
    return False


def pythonw() -> Path:
    exe = Path(sys.executable).resolve()
    candidate = exe.with_name("pythonw.exe")
    return candidate if candidate.exists() else exe


def ensure_tray() -> None:
    if os.name != "nt" or not load_config().getboolean("settings", "add_to_tray", fallback=False):
        return
    user32 = ctypes.windll.user32
    user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowW.restype = wintypes.HWND
    if user32.FindWindowW(TRAY_CLASS, None):
        return
    flags = 0x00000008 | 0x00000200 | 0x08000000
    subprocess.Popen([str(pythonw()), str(base_dir() / Path(__file__).name), "tray"], cwd=str(base_dir()), creationflags=flags, close_fds=True)
    for _ in range(20):
        if user32.FindWindowW(TRAY_CLASS, None):
            return
        time.sleep(0.05)


def send_tray_status(file: str, percent: int, done: int, total: int, state: str = "extracting") -> None:
    if os.name != "nt" or not load_config().getboolean("settings", "add_to_tray", fallback=False):
        return
    ensure_tray()
    user32 = ctypes.windll.user32
    user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowW.restype = wintypes.HWND
    user32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, ctypes.c_size_t, ctypes.c_ssize_t]
    user32.SendMessageW.restype = ctypes.c_ssize_t
    hwnd = user32.FindWindowW(TRAY_CLASS, None)
    if not hwnd:
        return
    payload = json.dumps({"file": file, "percent": percent, "done": done, "total": total, "state": state}).encode("utf-8") + b"\0"
    buffer = ctypes.create_string_buffer(payload)

    class CopyData(ctypes.Structure):
        _fields_ = [("dwData", ctypes.c_size_t), ("cbData", wintypes.DWORD), ("lpData", ctypes.c_void_p)]

    data = CopyData(1, len(payload), ctypes.cast(buffer, ctypes.c_void_p))
    user32.SendMessageW(hwnd, 0x004A, 0, ctypes.addressof(data))


def process_file(source: Path, seen: dict[str, tuple[int, int]] | None = None) -> Path | None:
    source = source.resolve()
    if not source.is_file() or source.name.lower().endswith(TEMP_SUFFIXES):
        return None
    config = load_config()
    settings = config["settings"]
    if excluded(source, settings.get("filetypes_to_exclude", "")):
        return None
    suffix = archive_suffix(source)
    if not suffix:
        return None
    current = signature(source)
    key = str(source).lower()
    if seen is not None and seen.get(key) == current:
        return None
    _, dump = paths(config)
    dump.mkdir(parents=True, exist_ok=True)
    destination = output_folder(source, suffix, dump)
    destination.mkdir(parents=True, exist_ok=False)
    last_percent = -1
    last_done = 0
    last_total = source.stat().st_size

    def update(done: int, total: int) -> None:
        nonlocal last_percent, last_done, last_total
        last_done = done
        last_total = total
        percent = 100 if total <= 0 and done else int(min(100, max(0, done * 100 // max(total, 1))))
        if percent != last_percent:
            last_percent = percent
            send_tray_status(source.name, percent, done, total)

    try:
        if suffix == ".zip":
            extract_zip(source, destination, update)
        elif suffix in {".tar", ".tar.gz", ".tar.bz2", ".tar.xz", ".tgz", ".tbz2", ".txz"}:
            extract_tar(source, destination, update)
        else:
            extract_stream(source, destination, suffix, update)
    except Exception:
        shutil.rmtree(destination, ignore_errors=True)
        send_tray_status(source.name, 0, 0, 0, "failed")
        raise
    if seen is not None:
        seen[key] = current
    send_tray_status(source.name, 100, last_total, last_total, "done")
    if settings.getboolean("open_folder", fallback=True) and os.name == "nt":
        os.startfile(destination)
    try:
        handle_original(source, settings.get("move_original_after", "no"))
    except OSError:
        pass
    return destination


def watcher_mutex() -> wintypes.HANDLE | None:
    kernel32 = ctypes.windll.kernel32
    kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.CreateMutexW.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    handle = kernel32.CreateMutexW(None, False, "Local\\" + APP_NAME + "-Watcher")
    if handle and kernel32.GetLastError() == 183:
        kernel32.CloseHandle(handle)
        return None
    return handle


def watch() -> int:
    if os.name != "nt":
        return 1
    guard = watcher_mutex()
    if not guard:
        return 0
    config = load_config()
    downloads, _ = paths(config)
    downloads.mkdir(parents=True, exist_ok=True)
    if config.getboolean("settings", "add_to_tray", fallback=False):
        ensure_tray()
    stable_seconds = max(0.5, config.getfloat("settings", "stable_seconds", fallback=2.0))
    kernel32 = ctypes.windll.kernel32
    kernel32.CreateEventW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.CreateEventW.restype = wintypes.HANDLE
    kernel32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel32.CreateFileW.restype = wintypes.HANDLE
    kernel32.ReadDirectoryChangesW.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD, wintypes.BOOL, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p, ctypes.c_void_p]
    kernel32.ReadDirectoryChangesW.restype = wintypes.BOOL
    kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    stop_event = kernel32.CreateEventW(None, True, False, STOP_EVENT)
    handle = kernel32.CreateFileW(str(downloads), 0x0001, 0x00000001 | 0x00000002 | 0x00000004, None, 3, 0x02000000, None)
    if handle == wintypes.HANDLE(-1).value:
        kernel32.CloseHandle(stop_event)
        kernel32.CloseHandle(guard)
        return 2
    buffer = ctypes.create_string_buffer(65536)
    returned = wintypes.DWORD()
    seen: dict[str, tuple[int, int]] = {}
    try:
        while True:
            if kernel32.WaitForSingleObject(stop_event, 0) == 0:
                return 0
            ok = kernel32.ReadDirectoryChangesW(handle, ctypes.byref(buffer), len(buffer), False, 0x00000001 | 0x00000008 | 0x00000010, ctypes.byref(returned), None, None)
            if not ok:
                return 3
            if kernel32.WaitForSingleObject(stop_event, 0) == 0:
                return 0
            names: set[str] = set()
            offset = 0
            data = buffer.raw[:returned.value]
            while offset + 12 <= len(data):
                next_offset = int.from_bytes(data[offset:offset + 4], "little")
                name_len = int.from_bytes(data[offset + 8:offset + 12], "little")
                name = data[offset + 12:offset + 12 + name_len].decode("utf-16-le", errors="ignore")
                if name:
                    names.add(name)
                if next_offset == 0:
                    break
                offset += next_offset
            for name in names:
                path = downloads / name
                try:
                    if not path.is_file() or path.name.lower().endswith(TEMP_SUFFIXES) or not archive_suffix(path):
                        continue
                    if stable(path, stable_seconds):
                        process_file(path, seen)
                except Exception:
                    pass
    finally:
        kernel32.CloseHandle(handle)
        kernel32.CloseHandle(stop_event)
        kernel32.CloseHandle(guard)


def set_startup(enabled: bool, script: Path) -> None:
    import winreg
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
        if enabled:
            command = subprocess.list2cmdline([str(pythonw()), str(script), "watch"])
            winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, command)
        else:
            try:
                winreg.DeleteValue(key, APP_NAME)
            except FileNotFoundError:
                pass


def launch_watcher(script: Path) -> None:
    flags = 0x00000008 | 0x00000200 | 0x08000000 if os.name == "nt" else 0
    subprocess.Popen([str(pythonw()), str(script), "watch"], cwd=str(script.parent), creationflags=flags, close_fds=True)


def stop_background() -> None:
    if os.name != "nt":
        return
    kernel32 = ctypes.windll.kernel32
    kernel32.OpenEventW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.OpenEventW.restype = wintypes.HANDLE
    kernel32.SetEvent.argtypes = [wintypes.HANDLE]
    kernel32.SetEvent.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    event = kernel32.OpenEventW(0x0002, False, STOP_EVENT)
    if event:
        kernel32.SetEvent(event)
        kernel32.CloseHandle(event)
    try:
        downloads, _ = paths(load_config())
        wake = downloads / ".auto-unzip-wake.tmp"
        wake.touch(exist_ok=True)
        wake.unlink(missing_ok=True)
    except OSError:
        pass


def tray() -> int:
    if os.name != "nt":
        return 1
    kernel32 = ctypes.windll.kernel32
    user32 = ctypes.windll.user32
    shell32 = ctypes.windll.shell32
    kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.CreateMutexW.restype = wintypes.HANDLE
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    kernel32.GetModuleHandleW.restype = wintypes.HMODULE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    user32.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    user32.LoadImageW.restype = wintypes.HANDLE
    user32.DestroyIcon.argtypes = [wintypes.HANDLE]
    user32.DestroyIcon.restype = wintypes.BOOL
    user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowW.restype = wintypes.HWND
    user32.CreatePopupMenu.argtypes = []
    user32.CreatePopupMenu.restype = wintypes.HANDLE
    user32.AppendMenuW.argtypes = [wintypes.HANDLE, wintypes.UINT, ctypes.c_size_t, wintypes.LPCWSTR]
    user32.AppendMenuW.restype = wintypes.BOOL
    user32.TrackPopupMenu.argtypes = [wintypes.HANDLE, wintypes.UINT, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.HWND, ctypes.c_void_p]
    user32.TrackPopupMenu.restype = wintypes.UINT
    user32.MessageBoxW.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.UINT]
    user32.MessageBoxW.restype = ctypes.c_int
    user32.DestroyMenu.argtypes = [wintypes.HANDLE]
    user32.DestroyMenu.restype = wintypes.BOOL
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetForegroundWindow.restype = wintypes.BOOL
    user32.RegisterWindowMessageW.argtypes = [wintypes.LPCWSTR]
    user32.RegisterWindowMessageW.restype = wintypes.UINT
    guard = kernel32.CreateMutexW(None, False, "Local\\" + APP_NAME + "-Tray")
    if guard and kernel32.GetLastError() == 183:
        kernel32.CloseHandle(guard)
        return 0

    LRESULT = ctypes.c_ssize_t
    WPARAM = ctypes.c_size_t
    LPARAM = ctypes.c_ssize_t
    WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT, WPARAM, LPARAM)

    class Point(ctypes.Structure):
        _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

    class CopyData(ctypes.Structure):
        _fields_ = [("dwData", ctypes.c_size_t), ("cbData", wintypes.DWORD), ("lpData", ctypes.c_void_p)]

    class WndClass(ctypes.Structure):
        _fields_ = [
            ("style", wintypes.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int),
            ("cbWndExtra", ctypes.c_int), ("hInstance", wintypes.HINSTANCE), ("hIcon", wintypes.HANDLE),
            ("hCursor", wintypes.HANDLE), ("hbrBackground", wintypes.HANDLE),
            ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR),
        ]

    class Guid(ctypes.Structure):
        _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD), ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

    class NotifyIcon(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD), ("hWnd", wintypes.HWND), ("uID", wintypes.UINT),
            ("uFlags", wintypes.UINT), ("uCallbackMessage", wintypes.UINT), ("hIcon", wintypes.HANDLE),
            ("szTip", wintypes.WCHAR * 128), ("dwState", wintypes.DWORD), ("dwStateMask", wintypes.DWORD),
            ("szInfo", wintypes.WCHAR * 256), ("uTimeoutOrVersion", wintypes.UINT),
            ("szInfoTitle", wintypes.WCHAR * 64), ("dwInfoFlags", wintypes.DWORD),
            ("guidItem", Guid), ("hBalloonIcon", wintypes.HANDLE),
        ]

    user32.RegisterClassW.argtypes = [ctypes.POINTER(WndClass)]
    user32.RegisterClassW.restype = wintypes.ATOM
    user32.CreateWindowExW.argtypes = [wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.HWND, wintypes.HANDLE, wintypes.HINSTANCE, ctypes.c_void_p]
    user32.CreateWindowExW.restype = wintypes.HWND
    user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, ctypes.c_size_t, ctypes.c_ssize_t]
    user32.DefWindowProcW.restype = ctypes.c_ssize_t
    user32.DestroyWindow.argtypes = [wintypes.HWND]
    user32.DestroyWindow.restype = wintypes.BOOL
    shell32.Shell_NotifyIconW.argtypes = [wintypes.DWORD, ctypes.POINTER(NotifyIcon)]
    shell32.Shell_NotifyIconW.restype = wintypes.BOOL

    callback_message = 0x8001
    taskbar_created = user32.RegisterWindowMessageW("TaskbarCreated")
    icons = base_dir() / "tray-icons"
    current_icon = None
    nid = NotifyIcon()

    def load_icon(name: str):
        return user32.LoadImageW(None, str(icons / name), 1, 16, 16, 0x0010)

    def set_icon(hwnd, name: str, tip: str) -> None:
        nonlocal current_icon
        icon = load_icon(name)
        if not icon:
            return
        nid.cbSize = ctypes.sizeof(NotifyIcon)
        nid.hWnd = hwnd
        nid.uID = 1
        nid.uFlags = 0x00000002 | 0x00000004
        nid.hIcon = icon
        nid.szTip = tip[:127]
        shell32.Shell_NotifyIconW(1, ctypes.byref(nid))
        if current_icon:
            user32.DestroyIcon(current_icon)
        current_icon = icon

    def update_status(hwnd, status: dict) -> None:
        state = status.get("state", "extracting")
        name = str(status.get("file", ""))
        percent = max(0, min(100, int(status.get("percent", 0))))
        done = int(status.get("done", 0))
        total = int(status.get("total", 0))
        if state == "failed":
            set_icon(hwnd, "au logo1.ico", f"{name} | failed")
            return
        if state == "done":
            percent = 100
        index = round(percent * (len(TRAY_FRAMES) - 1) / 100)
        suffix = f" | {percent}% | {done / 1048576:.1f} MB/{total / 1048576:.1f} MB"
        tip = name[:max(1, 127 - len(suffix))] + suffix
        set_icon(hwnd, TRAY_FRAMES[index], tip)

    @WNDPROC
    def wndproc(hwnd, msg, wparam, lparam):
        if msg == taskbar_created:
            nid.uFlags = 0x00000001 | 0x00000002 | 0x00000004
            nid.uCallbackMessage = callback_message
            shell32.Shell_NotifyIconW(0, ctypes.byref(nid))
            return 0
        if msg == 0x004A:
            data = ctypes.cast(lparam, ctypes.POINTER(CopyData)).contents
            try:
                raw = ctypes.string_at(data.lpData, data.cbData).rstrip(b"\0")
                update_status(hwnd, json.loads(raw.decode("utf-8")))
            except Exception:
                pass
            return 1
        if msg == callback_message and int(lparam) == 0x0205:
            menu = user32.CreatePopupMenu()
            user32.AppendMenuW(menu, 0, 1, "Config")
            user32.AppendMenuW(menu, 0, 2, "Exit")
            user32.AppendMenuW(menu, 0, 3, "Open Output Location")
            user32.AppendMenuW(menu, 0, 5, "Uninstall")
            user32.AppendMenuW(menu, 0, 4, "Close")
            point = Point()
            user32.GetCursorPos(ctypes.byref(point))
            user32.SetForegroundWindow(hwnd)
            command = user32.TrackPopupMenu(menu, 0x0100 | 0x0002, point.x, point.y, 0, hwnd, None)
            user32.DestroyMenu(menu)
            if command == 1:
                os.startfile(base_dir() / "config.ini")
            elif command == 2:
                stop_background()
                user32.DestroyWindow(hwnd)
            elif command == 3:
                _, dump = paths(load_config())
                dump.mkdir(parents=True, exist_ok=True)
                os.startfile(dump)
            elif command == 5:
                answer = user32.MessageBoxW(hwnd, "Uninstall Auto_Unzip-Save-Open?\n\nExtracted files will be kept.", APP_NAME, 0x00000024)
                if answer == 6 and uninstall(False) == 0:
                    user32.DestroyWindow(hwnd)
            elif command == 4:
                user32.DestroyWindow(hwnd)
            return 0
        if msg == 0x0002:
            shell32.Shell_NotifyIconW(2, ctypes.byref(nid))
            user32.PostQuitMessage(0)
            return 0
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    instance = kernel32.GetModuleHandleW(None)
    wc = WndClass()
    wc.lpfnWndProc = wndproc
    wc.hInstance = instance
    wc.lpszClassName = TRAY_CLASS
    user32.RegisterClassW(ctypes.byref(wc))
    hwnd = user32.CreateWindowExW(0, TRAY_CLASS, APP_NAME, 0, 0, 0, 0, 0, None, None, instance, None)
    if not hwnd:
        if guard:
            kernel32.CloseHandle(guard)
        return 2
    nid.cbSize = ctypes.sizeof(NotifyIcon)
    nid.hWnd = hwnd
    nid.uID = 1
    nid.uFlags = 0x00000001 | 0x00000002 | 0x00000004
    nid.uCallbackMessage = callback_message
    nid.hIcon = load_icon("au logo1.ico")
    current_icon = nid.hIcon
    nid.szTip = "Watching Downloads"
    for _ in range(10):
        if shell32.Shell_NotifyIconW(0, ctypes.byref(nid)):
            break
        time.sleep(0.25)
    msg = wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))
    if current_icon:
        user32.DestroyIcon(current_icon)
    if guard:
        kernel32.CloseHandle(guard)
    return 0


def install() -> int:
    if os.name != "nt":
        print("Windows only.")
        return 1
    add_startup = input("Add to startup? (Y / N) ").strip().lower() in {"y", "yes"}
    add_tray = input("Add to tray? (Y / N) ").strip().lower() in {"y", "yes"}
    downloads_text = input("Downloads folder? Leave blank = default ").strip()
    downloads = expand_path(downloads_text) if downloads_text else (Path.home() / "Downloads").resolve()
    dump_text = input("Dump folder? Leave blank = default ").strip()
    dump = expand_path(dump_text) if dump_text else (downloads / "Dump").resolve()
    install_text = input("Install folder? Leave blank = default ").strip()
    default_install = Path(os.environ["LOCALAPPDATA"]) / APP_NAME
    folder = expand_path(install_text) if install_text else default_install.resolve()
    excludes = input("File types to exclude? Put a comma between each file type ").strip()
    move_after = input('Move the original ZIP after extraction? Usage: Enter a directory address, "N"/"no", or "recycle" to move it to the Recycle Bin. ').strip()
    if not move_after or move_after.lower() in {"n", "no"}:
        move_after = "no"
    elif move_after.lower() == "recycle":
        move_after = "recycle"
    else:
        move_folder = expand_path(move_after)
        move_folder.mkdir(parents=True, exist_ok=True)
        move_after = str(move_folder)
    folder.mkdir(parents=True, exist_ok=True)
    downloads.mkdir(parents=True, exist_ok=True)
    dump.mkdir(parents=True, exist_ok=True)
    script = folder / "Auto_Unzip-Save-Open.py"
    shutil.copy2(Path(__file__).resolve(), script)
    shutil.copytree(base_dir() / "tray-icons", folder / "tray-icons", dirs_exist_ok=True)
    config = configparser.ConfigParser(interpolation=None)
    config["settings"] = {
        "downloads_folder": str(downloads), "dump_folder": str(dump), "install_folder": str(folder),
        "filetypes_to_exclude": excludes, "move_original_after": move_after, "open_folder": "yes",
        "stable_seconds": "2.0", "startup": "yes" if add_startup else "no", "add_to_tray": "yes" if add_tray else "no",
    }
    with (folder / "config.ini").open("w", encoding="utf-8") as handle:
        config.write(handle)
    set_startup(add_startup, script)
    launch_watcher(script)
    print(f"Installed: {folder}")
    return 0


def close_tray() -> None:
    if os.name != "nt":
        return
    user32 = ctypes.windll.user32
    user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowW.restype = wintypes.HWND
    user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, ctypes.c_size_t, ctypes.c_ssize_t]
    user32.PostMessageW.restype = wintypes.BOOL
    hwnd = user32.FindWindowW(TRAY_CLASS, None)
    if hwnd:
        user32.PostMessageW(hwnd, 0x0010, 0, 0)


def schedule_install_cleanup(folder: Path, protected: list[Path]) -> None:
    folder = folder.resolve()
    protected = [path.resolve() for path in protected]
    names = ["Auto_Unzip-Save-Open.py", "config.ini", "tray-icons"]
    targets = []
    for name in names:
        target = (folder / name).resolve()
        keep = False
        for path in protected:
            try:
                path.relative_to(target)
                keep = True
                break
            except ValueError:
                pass
        if not keep:
            targets.append(str(target))
    ps = ["Start-Sleep -Seconds 2"]
    for target in targets:
        escaped = target.replace("'", "''")
        ps.append(f"Remove-Item -LiteralPath '{escaped}' -Recurse -Force -ErrorAction SilentlyContinue")
    escaped_folder = str(folder).replace("'", "''")
    ps.append(f"Remove-Item -LiteralPath '{escaped_folder}' -Force -ErrorAction SilentlyContinue")
    subprocess.Popen(
        ["powershell.exe", "-NoProfile", "-WindowStyle", "Hidden", "-Command", "; ".join(ps)],
        creationflags=0x08000000 | 0x00000008,
        close_fds=True,
    )

def uninstall(close_tray_window: bool = True) -> int:
    if os.name != "nt":
        return 1
    config = load_config()
    install_text = config.get("settings", "install_folder", fallback="").strip()
    folder = expand_path(install_text) if install_text else base_dir()
    try:
        downloads, dump = paths(config)
    except Exception:
        downloads = Path.home() / "Downloads"
        dump = downloads / "Dump"
    protected = [downloads, dump]
    move_after = config.get("settings", "move_original_after", fallback="no").strip()
    if move_after and move_after.lower() not in {"n", "no", "recycle"}:
        protected.append(expand_path(move_after))
    set_startup(False, folder / "Auto_Unzip-Save-Open.py")
    stop_background()
    if close_tray_window:
        close_tray()
    schedule_install_cleanup(folder, protected)
    print("Uninstalled. Extracted files were left untouched.")
    return 0


def run_portable_session() -> int:
    """Run the portable watcher for the lifetime of this console session."""
    if os.name != "nt":
        print("Windows only.")
        return 1

    import msvcrt

    script = Path(__file__).resolve()
    child = subprocess.Popen(
        [sys.executable, str(script), "watch"],
        cwd=str(script.parent),
    )

    kernel32 = ctypes.windll.kernel32
    HANDLER = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.DWORD)
    stopping = False

    def stop_session() -> None:
        nonlocal stopping
        if stopping:
            return
        stopping = True
        stop_background()
        close_tray()

    @HANDLER
    def console_handler(ctrl_type):
        # CTRL_C, CTRL_BREAK, CTRL_CLOSE, CTRL_LOGOFF, CTRL_SHUTDOWN
        if ctrl_type in (0, 1, 2, 5, 6):
            stop_session()
            return True
        return False

    kernel32.SetConsoleCtrlHandler.argtypes = [HANDLER, wintypes.BOOL]
    kernel32.SetConsoleCtrlHandler.restype = wintypes.BOOL
    kernel32.SetConsoleCtrlHandler(console_handler, True)

    print("AUSO portable is running for this Windows session.")
    print("Press S to stop. Closing this window also stops AUSO.")

    try:
        while child.poll() is None:
            if msvcrt.kbhit():
                key = msvcrt.getwch()
                if key.lower() == "s":
                    stop_session()
                    break
                # Consume the second code emitted by arrows/function keys.
                if key in ("\x00", "\xe0") and msvcrt.kbhit():
                    msvcrt.getwch()
            time.sleep(0.05)
    finally:
        stop_session()
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.terminate()
            try:
                child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                child.kill()
        kernel32.SetConsoleCtrlHandler(console_handler, False)

    return 0

def main() -> int:
    parser = argparse.ArgumentParser(prog="Auto_Unzip-Save-Open")
    parser.add_argument("command", nargs="?", choices=("install", "watch", "process", "tray", "uninstall", "session"), default="install")
    parser.add_argument("path", nargs="?")
    args = parser.parse_args()
    if args.command == "install":
        return install()
    if args.command == "watch":
        return watch()
    if args.command == "session":
        return run_portable_session()
    if args.command == "tray":
        return tray()
    if args.command == "uninstall":
        return uninstall()
    if not args.path:
        return 2
    result = process_file(Path(args.path))
    if result:
        print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
