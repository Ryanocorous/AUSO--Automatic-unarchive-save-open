@echo off
cd /d "%~dp0"
echo [I] Install
echo [U] Uninstall
set /p AUSO_ACTION=Choose (I / U): 
if /i "%AUSO_ACTION%"=="U" (
    set "AUSO_COMMAND=uninstall"
) else (
    set "AUSO_COMMAND=install"
)
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 "Auto_Unzip-Save-Open.py" %AUSO_COMMAND%
) else (
    python "Auto_Unzip-Save-Open.py" %AUSO_COMMAND%
)
pause
