@echo off
setlocal
cd /d "%~dp0"
title AUSO Portable - Press S to Stop

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 "Auto_Unzip-Save-Open.py" session
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        python "Auto_Unzip-Save-Open.py" session
    ) else (
        echo Python was not found.
        echo Install Python 3 or add it to PATH, then run this file again.
        pause
        exit /b 1
    )
)

endlocal
